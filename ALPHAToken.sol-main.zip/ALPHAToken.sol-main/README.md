# ALPHAToken.sol
 Cryptocurrency token
